using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MedBubble : Movement
{
    //Fields
    private int hitsLeft;

    // Start is called before the first frame update
    void Start()
    {
        hitsLeft = 2;
        cam = Camera.main;
    }

    // Update is called once per frame
    void Update()
    {
        if (spm.spawned)
        {
            base.FloatUp(pingPongSpeed);
        }
        base.DespawnAtTop();
    }
}
